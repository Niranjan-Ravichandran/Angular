import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databinding',
  templateUrl: './databinding.component.html',
  styleUrls: ['./databinding.component.css']
})
export class DatabindingComponent implements OnInit {
  imageUrl : string = '../../assets/SampleImage2.PNG';
  colSpanTwo: number = 2;
  isStyleBinding: boolean = false;
  name = 'John';
  constructor() { }

  ngOnInit(): void {
  }
  onStyleBinding(){
    this.isStyleBinding = !this.isStyleBinding;
  }
}
