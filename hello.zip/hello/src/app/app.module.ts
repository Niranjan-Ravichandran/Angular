import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HelloComponent } from './hello/hello.component';
import { StructuralComponent } from './structural/structural.component';
import { DatabindingComponent } from './databinding/databinding.component';
import { FormsModule } from '@angular/forms';
import { PipesComponent } from './pipes/pipes.component';
// registering 
import { registerLocaleData } from '@angular/common';
import localeFrench from '@angular/common/locales/fr';
import { SortPipe } from './sort.pipe';
registerLocaleData(localeFrench);

@NgModule({
  declarations: [
    AppComponent,
    HelloComponent,
    StructuralComponent,
    DatabindingComponent,
    PipesComponent,
    SortPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
