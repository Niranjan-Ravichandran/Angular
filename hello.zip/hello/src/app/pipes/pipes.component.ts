import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {

  product: Object = {
    'productCode': 'PROD_P001', 'productName': 'Laptop', 'productPrice': 25000,
    'purchaseDate': '5/12/2017', 'productTax': '0.1', 'productRating': 4.53
  };



  //i18nplural
  messages: any[] = [0,1,3,0,1,2,0,1];
  messageMapping = {
    '=0': 'No messages.',
    '=1': 'One message.',
    'other': '# messages.'
  };


  selectedGender:string='';
  genderMap: any = {
    0: 'Welcome him',
    1: 'Welcome her',
    2: 'Welcome other'
  };


sortoption: string = '';
productsList: any = [
  { productName: 'Samsung J7', price: 18000 },
  { productName: 'Apple iPhone 6S', price: 60000 },
  { productName: 'Lenovo K5 Note', price: 10000 },
  { productName: 'Nokia 6', price: 15000 },
  { productName: 'Vivo V5 Plus', price: 26000 },
];
  constructor() { }
  

  ngOnInit(): void {
  }

}
