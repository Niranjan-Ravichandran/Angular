import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-structural',
  templateUrl: './structural.component.html',
  styleUrls: ['./structural.component.css']
})
export class StructuralComponent implements OnInit {

  toggle: boolean = false;
  value: number = 0;
  colorName:string = 'yellow';
  color:string = 'red';
  borderStyle = '1px solid black';
  fontWeight = '1000';
  isBordered: boolean = false;
  isColor: boolean =  false;
  courses: any[] = [
    { id: 100, name: "TypeScript" },
    { id: 200, name: "Angular" },
    { id: 300, name: "Node JS" },
    { id: 400, name: "TypeScript" }
  ];

  constructor() { }

  ngOnInit(): void {
  }

  onToggle() {
    this.toggle = !this.toggle;
  }

  nextChoice() {
      this.value++;
  }

  onBorderChange(){
    this.isBordered = !this.isBordered;
  }
  onBorderAndColorChange(){
    this.isBordered = !this.isBordered;
    this.isColor = !this.isColor;
  }
}
