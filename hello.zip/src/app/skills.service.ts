import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Skills } from './skills';
import { SKILLS } from './skills-data';

@Injectable({
  providedIn: 'root'
})
export class SkillsService {

  constructor() { }

  getSkills(){
    return SKILLS;
  }

  getSkillsById(id:number):Skills|undefined{
    return SKILLS.find(i=>i.id == id);
  }
}
