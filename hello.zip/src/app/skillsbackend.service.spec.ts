import { TestBed } from '@angular/core/testing';

import { SkillsbackendService } from './skillsbackend.service';

describe('SkillsbackendService', () => {
  let service: SkillsbackendService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SkillsbackendService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
