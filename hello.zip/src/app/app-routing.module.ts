import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LifecycleComponent } from './lifecycle/lifecycle.component';
import { LogincomponentComponent } from './logincomponent/logincomponent.component';
import { LoginguardService } from './loginguard.service';
import { NestedComponent } from './nested/nested.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { ServiceComponent } from './service/service.component';
import { SkilldetailComponent } from './skilldetail/skilldetail.component';
import { SkillsFormComponent } from './skills-form/skills-form.component';

const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
    { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
    { path: 'register', component: ReactiveFormComponent },
    { path: 'skillForm', component: SkillsFormComponent },
    { path: 'skill', component: ServiceComponent , canActivate:[LoginguardService]},
    { path: 'detail/:id', component: SkilldetailComponent },
   { path: 'login', component: LogincomponentComponent },
   { path: 'nested', component: NestedComponent },
   { path: 'profile', component: LifecycleComponent }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
