import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Skills } from '../skills';
import { SkillsService } from '../skills.service';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

 @Input() skills:Skills[]=[];
 @Input("skill") skillsFromParent:Skills[]=[];
 @Output() registerEvent = new EventEmitter<string>();
 @Input() title!: string;

 constructor(private skillsService: SkillsService,private router:Router) { }

 ngOnInit(): void {
   this.getSkills();
 }

 getSkills(){
   this.skills = this.skillsService.getSkills();
   //this.skills.slice(1,5);
 }
 gotoDetail(skill: Skills): void {
   console.log(skill);
   this.router.navigate(['/detail', skill.id]);
 }
 register(skill: Skills) {
  this.registerEvent.emit(skill.name);
}
ngOnChanges(changes: any): void {
  console.log('changes in child:' + JSON.stringify(changes));
}

}
