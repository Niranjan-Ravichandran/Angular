import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginserviceService } from './loginservice.service';
import { Skills } from './skills';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [/*<< service name >>*/],
})
export class AppComponent {
  title = 'hello';
  constructor(private loginService:LoginserviceService,private router:Router){

  }
  onLogOut(){
this.loginService.logOut();
alert("You're logged out");
this.router.navigate(['/dashboard']);
  }

}
