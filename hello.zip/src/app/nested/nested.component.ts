import { Component, OnInit } from '@angular/core';
import { Skills } from '../skills';

@Component({
  selector: 'app-nested',
  templateUrl: './nested.component.html',
  styleUrls: ['./nested.component.css']
})
export class NestedComponent implements OnInit {
  show=false;
  message!: string;
  skills: Skills[] = [
    { "id": 1, "name": "HTML 5" },
    { "id": 2, "name": "CSS 3" },
    { "id": 3, "name": "Java Script" },
    { "id": 4, "name": "Angular" }
  ]
  constructor() { }
  skillsReg(skillName: string) {
    this.message = `Your registration for ${skillName} is successful`;
  }
  ngOnInit(): void {
  }

}
