export class Skills {
    id!: number;
    name!: string;
}
