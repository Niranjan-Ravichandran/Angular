import { Component, OnInit } from '@angular/core';
import {
   DoCheck, AfterContentInit, AfterContentChecked,
  AfterViewInit, AfterViewChecked,
  OnDestroy
} from '@angular/core';
@Component({
  selector: 'app-lifecycle',
  templateUrl: './lifecycle.component.html',
  styleUrls: ['./lifecycle.component.css']
})
export class LifecycleComponent implements OnInit, DoCheck,
AfterContentInit, AfterContentChecked,
AfterViewInit, AfterViewChecked,
OnDestroy {

  data = 'John';
  ngOnInit() {
      console.log('Init');
  }
  ngDoCheck(): void {
      console.log('Change detected do check');
  }
  ngAfterContentInit(): void {
      console.log('After content init');
  }
  ngAfterContentChecked(): void {
      console.log('After content checked');
  }
  ngAfterViewInit(): void {
      console.log('After view init');
  }
  ngAfterViewChecked(): void {
      console.log('After view checked');
  }
  ngOnDestroy(): void {
      console.log('Destroy');
  }
}
