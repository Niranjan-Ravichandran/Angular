import { Component, OnInit } from '@angular/core';
import { SkillsForm } from '../skillsForm';

@Component({
  selector: 'app-skills-form',
  templateUrl: './skills-form.component.html',
  styleUrls: ['./skills-form.component.css']
})
export class SkillsFormComponent implements OnInit {
  submitted = false;
  skills = ["HTML 5", "CSS 3","JS","Bootstrap","Angular 12"];
  skillForm: SkillsForm = new SkillsForm(1,"John","");
  constructor() { }

  ngOnInit(): void {
  }
  onSubmit() { this.submitted = true; }
}
