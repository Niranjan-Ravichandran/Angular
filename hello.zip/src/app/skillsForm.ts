export class SkillsForm {
    constructor(
      public registrationNumber: number,
      public name: string,
      public skills: string
    ) { }
  }
  