import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Skills } from '../skills';
import { SkillsService } from '../skills.service';

@Component({
  selector: 'app-skilldetail',
  templateUrl: './skilldetail.component.html',
  styleUrls: ['./skilldetail.component.css']
})
export class SkilldetailComponent implements OnInit {

  skills:Skills[]=[];
  id!: number;
  skill: Skills|undefined;

  constructor(private route: ActivatedRoute,
    private skillsService: SkillsService
  ) { }
getSkill(id:number){
this.skill = this.skillsService.getSkillsById(id);
console.log(this.skill);
}
  ngOnInit(): void {
    console.log("oninit");
    this.route.params.subscribe((params) => {
      console.log(params.id);
      this.id = params.id
      this.getSkill(this.id);

    });
}
}
