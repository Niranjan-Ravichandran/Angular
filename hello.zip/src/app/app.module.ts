import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HelloComponent } from './hello/hello.component';
import { StructuralComponent } from './structural/structural.component';
import { DatabindingComponent } from './databinding/databinding.component';
import { FormsModule } from '@angular/forms';
import { PipesComponent } from './pipes/pipes.component';
// registering 
import { registerLocaleData } from '@angular/common';
import localeFrench from '@angular/common/locales/fr';
import { SortPipe } from './sort.pipe';
import { ServiceComponent } from './service/service.component';
import { SkillsService } from './skills.service';
registerLocaleData(localeFrench);
// 
import { HttpClientModule } from '@angular/common/http';
import { SkillsbackendService } from './skillsbackend.service';
import { SkillsFormComponent } from './skills-form/skills-form.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SkilldetailComponent } from './skilldetail/skilldetail.component';
import { LogincomponentComponent } from './logincomponent/logincomponent.component';
import { NestedComponent } from './nested/nested.component';
import { ChildComponent } from './child/child.component';
import { LifecycleComponent } from './lifecycle/lifecycle.component';

@NgModule({
  declarations: [
    AppComponent,
    HelloComponent,
    StructuralComponent,
    DatabindingComponent,
    PipesComponent,
    SortPipe,
    ServiceComponent,
    SkillsFormComponent,
    ReactiveFormComponent,
    DashboardComponent,
    SkilldetailComponent,
    LogincomponentComponent,
    NestedComponent,
    ChildComponent,
    LifecycleComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [SkillsService,SkillsbackendService],
  bootstrap: [AppComponent]
})
export class AppModule { }
