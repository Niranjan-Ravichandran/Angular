import { Component, OnInit } from '@angular/core';
import { Skills } from '../skills';
import { SkillsService } from '../skills.service';
import { SkillsbackendService } from '../skillsbackend.service';

@Component({
  selector: 'app-service',
  templateUrl: './service.component.html',
  styleUrls: ['./service.component.css']
})
export class ServiceComponent implements OnInit {

  skills!: Skills[];
  skillsBE!: Skills[];
  errorMessage!: string;
  constructor(private skillsService: SkillsService,private skillsBackendService:SkillsbackendService) { }

  ngOnInit(): void {
    this.getSkills();
    this.getSkillsFromBackEnd();
  }

  getSkills(){
    this.skills = this.skillsService.getSkills();
  }

  getSkillsFromBackEnd(){
    this.skillsBackendService.getSkills().subscribe(
      data => this.skillsBE = data,
      err => this.errorMessage = err
    );
  }
}
