import { Skills } from './skills';
export var SKILLS: Skills[] = [
    { "id": 1, "name": "HTML 5" },
    { "id": 2, "name": "CSS 3" },
    { "id": 3, "name": "Java Script" },
    { "id": 4, "name": "Angular" },
    { "id": 5, "name": "React" },
    { "id": 6, "name": "Java 11" },
    { "id": 7, "name": "Apache Tomcat" },
    { "id": 8, "name": "Node Js" },
    { "id": 9, "name": "SQL" },
    { "id": 10, "name": "MongoDB" }
];
